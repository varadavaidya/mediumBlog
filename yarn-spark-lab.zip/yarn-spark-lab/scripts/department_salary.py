from pyspark.sql import SparkSession
from pyspark.sql.functions import avg, count

spark = (
    SparkSession.builder
    .appName("DepartmentSalaryAnalysis")
    .getOrCreate()
)

print("=== SPARK APPLICATION STARTED ===")

# Read data directly from HDFS
df = spark.read.csv(
    "hdfs://master:8020/user/spark/input/employees.csv",
    header=True,
    inferSchema=True
)
# Redistribute the DataFrame into 4 partitions
df = df.repartition(4)

print("Number of partitions:", df.rdd.getNumPartitions())

print("=== INPUT DATA ===")
df.show()

# Perform distributed aggregation
result = (
    df.groupBy("department")
      .agg(
          count("*").alias("employee_count"),
          avg("salary").alias("average_salary")
      )
)

print("=== DEPARTMENT SALARY ANALYSIS ===")
result.show()

# Keep output available for inspection
result.write.mode("overwrite").csv(
    "hdfs://master:8020/user/spark/output/department_salary"
)

spark.stop()