from pyspark.sql import SparkSession
import time

spark = (
    SparkSession.builder
    .appName("LongRunningYarnDemo")
    .getOrCreate()
)

sc = spark.sparkContext

print("=== LONG RUNNING JOB STARTED ===")

print("Waiting for 120 seconds...")
time.sleep(120)

print("=== RUNNING DISTRIBUTED TASKS ===")

rdd = sc.parallelize(range(100), 4)

result = rdd.map(
    lambda x: (x, x * x)
).collect()

print("Number of results:", len(result))

time.sleep(60)

spark.stop()