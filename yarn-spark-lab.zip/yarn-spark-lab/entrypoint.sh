#!/bin/bash
set -e

ROLE=$1
# Limit Hadoop daemon JVM heaps for this small lab
export HADOOP_HEAPSIZE_MAX=384
export YARN_RESOURCEMANAGER_HEAPSIZE=384
export YARN_NODEMANAGER_HEAPSIZE=384

cleanup() {
    echo "Stopping Hadoop services..."
    kill $(jobs -p) 2>/dev/null || true
    wait || true
}

trap cleanup EXIT
trap 'exit 143' SIGTERM
trap 'exit 130' SIGINT

if [ "$ROLE" = "master" ]; then

    if [ ! -d /data/hdfs/namenode/current ]; then
        echo "Formatting NameNode..."
        hdfs namenode -format -nonInteractive
    fi

    echo "Starting NameNode..."
    hdfs namenode &

    echo "Starting ResourceManager..."
    yarn resourcemanager &

elif [ "$ROLE" = "worker" ]; then

    echo "Waiting for NameNode..."
    until hdfs dfs -ls / >/dev/null 2>&1; do
        sleep 3
    done

    echo "Starting DataNode..."
    hdfs datanode &

    echo "Starting NodeManager..."
    yarn nodemanager &

else
    echo "Unknown role: $ROLE"
    exit 1
fi

if wait -n; then
    STATUS=0
else
    STATUS=$?
fi

echo "A Hadoop service exited. Container will stop."
exit "$STATUS"